package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.Given;
import io.github.bonigarcia.wdm.WebDriverManager;

public class stepdefinition {

	public ChromeDriver driver;
	
	@Given("open chromebrowser")
	public void openBrowser()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	
	@Given("load the appiclation url")
	public void loadURL()
	{
		driver.get("http://leaftaps.com/opentaps/");
	}
	
	@Given("enter the username as {string}")
	public void enter_the_username_as(String uname) {
		
		driver.findElement(By.id("username")).sendKeys(uname);
	    	}
	
	@Given("enter the password as {string}")
	public void enter_the_password_as(String pwad) {
		driver.findElement(By.id("password")).sendKeys(pwad);
	}
	
	@Given("click on login button")
	public void clickLogin()
	{
		driver.findElement(By.className("decorativeSubmit")).click();
	}
	
	@Given("home page should be displayed")
	public void homePage()
	{
		boolean displayed = driver.findElement(By.linkText("CRM/SFA")).isDisplayed();
		System.out.println(displayed);
	
	}

}