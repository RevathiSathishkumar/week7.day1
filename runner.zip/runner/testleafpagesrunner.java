package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features= {"src/test/java/features/createlead.feature",
		"src/test/java/features/deletelead.feature",
		"src/test/java/features/duplicatelead.feature",
		"src/test/java/features/editlead.feature",
		"src/test/java/features/mergelead.feature"},
                 glue="steps",
                 publish=true,
                 monochrome=true
                 )
public class testleafpagesrunner extends AbstractTestNGCucumberTests {
	
}
